SELECT DISTINCT name, telegram
FROM "2gis_businesses"
WHERE telegram IS NOT NULL