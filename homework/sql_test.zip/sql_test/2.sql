SELECT name, city
FROM "2gis_businesses"
WHERE name like "%котик%"
AND city == "Москва"