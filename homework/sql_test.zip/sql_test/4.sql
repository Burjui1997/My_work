SELECT address, category
FROM "2gis_businesses"
WHERE address like "%Тверская%" and category like "%досуг%"