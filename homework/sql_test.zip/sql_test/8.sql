SELECT name, payment_methods
FROM "2gis_businesses"
WHERE payment_methods like "%Наличный расчёт%"