SELECT name, address
FROM "2gis_businesses"
WHERE name like "Красное&%" and address like "%Арбат%"