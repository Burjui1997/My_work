SELECT DISTINCT [index], city, name, address
FROM "2gis_businesses"
WHERE [index] NOT NULL and [index] BETWEEN 141001 AND 141720