SELECT phone
FROM "2gis_businesses"
WHERE phone like "%8%-%800%" or phone like "%8%_%800%"
