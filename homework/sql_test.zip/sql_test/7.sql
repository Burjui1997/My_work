SELECT latitude, longitude
FROM "2gis_businesses"
WHERE latitude BETWEEN 55.75 and 55.80
AND longitude BETWEEN 37.60 and 37.65