from cities import cities
from utils import main
if __name__ == '__main__':
    main()




